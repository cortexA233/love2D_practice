function min(a,b)
  if(a<b) then
    return a
  end
  return b
end

function max(a,b)
  if(a>b) then
    return a
  end
  return b
end